# Local Lab (Path B) — kind + LocalStack, no AWS account needed

Goal: practice the ExternalSecret / SecretStore flow for free on your laptop.
LocalStack pretends to be AWS Secrets Manager. ESO is told to talk to it through the
`AWS_SECRETSMANAGER_ENDPOINT` environment variable.

**Difference from real EKS:** here ESO logs in with static dummy keys (`test`/`test`).
On real EKS you use IRSA / Pod Identity and no keys at all (that is Path A).

Prerequisites: Docker, `kind`, `kubectl`, `helm`, `aws` cli.

```bash
cd local-lab
bash 01-setup.sh          # kind cluster + LocalStack + ESO + secrets + store
kubectl apply -f ../k8s/01-namespace.yaml
kubectl apply -f ../k8s/03-externalsecret-basic.yaml
kubectl apply -f ../k8s/04-externalsecret-property.yaml
kubectl apply -f ../k8s/05-externalsecret-extract.yaml
kubectl apply -f ../k8s/06-externalsecret-template.yaml
kubectl apply -f ../k8s/07-demo-app.yaml
kubectl -n demo get externalsecret,secret
kubectl -n demo logs deploy/demo-app --tail=3
```

Rotate a secret locally:

```bash
export AWS_ACCESS_KEY_ID=test AWS_SECRET_ACCESS_KEY=test AWS_DEFAULT_REGION=us-east-1
aws --endpoint-url http://localhost:4566 secretsmanager put-secret-value \
  --secret-id demo/db-password --secret-string 'MyS3cretP@ss-v2'
sleep 75
kubectl -n demo get secret db-password-k8s -o jsonpath='{.data.password}' | base64 -d; echo
```

Cleanup: `kind delete cluster --name eso-local`

## Notes / caveats

- The ExternalSecrets in `../k8s/` are reused unchanged, because the local store has the same name
  (`aws-secretsmanager`). The region in the store (us-east-1) does not matter to LocalStack.
- LocalStack's image/licensing terms change over time. If `localstack/localstack` refuses to start and asks
  for an auth token, check the LocalStack docs for the current free option, or simply use Path A.
- I could not run this lab in my sandbox, so treat it as a starting point and read pod logs
  (`kubectl -n localstack logs deploy/localstack`) if something does not come up.
