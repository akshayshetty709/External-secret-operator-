#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo ">> 1. kind cluster"
kind create cluster --name eso-local --config kind-config.yaml

echo ">> 2. LocalStack (fake AWS Secrets Manager)"
kubectl apply -f localstack.yaml
kubectl -n localstack rollout status deploy/localstack --timeout=240s

echo ">> 3. External Secrets Operator"
helm repo add external-secrets https://charts.external-secrets.io
helm repo update
helm upgrade --install external-secrets external-secrets/external-secrets \
  -n external-secrets --create-namespace -f eso-values.yaml --wait

echo ">> 4. Create the demo secrets inside LocalStack"
export AWS_ACCESS_KEY_ID=test AWS_SECRET_ACCESS_KEY=test AWS_DEFAULT_REGION=us-east-1
EP=http://localhost:4566
aws --endpoint-url $EP secretsmanager create-secret --name demo/db-password --secret-string 'MyS3cretP@ss-v1' >/dev/null
aws --endpoint-url $EP secretsmanager create-secret --name demo/app-config \
  --secret-string '{"username":"admin","password":"S3cr3t!v1","host":"mydb.example.internal","port":"5432"}' >/dev/null
aws --endpoint-url $EP secretsmanager list-secrets --query 'SecretList[].Name'

echo ">> 5. ClusterSecretStore pointing at LocalStack"
kubectl apply -f clustersecretstore-local.yaml
sleep 5
kubectl get clustersecretstore

echo ">> Ready. Now apply the ExternalSecrets from ../k8s (see README)."
