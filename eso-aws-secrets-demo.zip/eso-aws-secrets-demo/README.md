# External Secrets Operator (ESO) + AWS Secrets Manager on EKS — Hands-on Demo

Learn how a Kubernetes cluster automatically pulls secrets from **AWS Secrets Manager** using the
**External Secrets Operator**, with **no AWS keys stored in the cluster** (IRSA).

```
 AWS Secrets Manager            EKS cluster
 ┌──────────────────┐          ┌───────────────────────────────────────────┐
 │ demo/db-password │◄──read───│  External Secrets Operator (IRSA role)    │
 │ demo/app-config  │          │        │ watches                          │
 └──────────────────┘          │        ▼                                  │
                               │  ExternalSecret (what to fetch)           │
                               │        │ creates / refreshes              │
                               │        ▼                                  │
                               │  K8s Secret ──► Pod (env var / volume)    │
                               └───────────────────────────────────────────┘
```

## Two ways to practice

| Path | Needs | Cost | Folder |
|------|-------|------|--------|
| **A. Real EKS + real AWS Secrets Manager** (what happens in real-time projects) | AWS account, aws cli, eksctl, kubectl, helm | EKS control plane + 2 nodes cost money while running (a few hours ≈ a few USD). **Always run cleanup.** | this folder |
| **B. Local lab** (kind + LocalStack, a fake AWS) | Docker, kind, kubectl, helm, aws cli | Free | `local-lab/` |

Do **Path B first** if you only want to understand the flow, then **Path A** to see the real IAM / IRSA part.
(Path B is a practice aid — it uses static test credentials, so it does NOT teach IRSA.)

## Folder structure

```
eso-aws-secrets-demo/
├── README.md
├── eksctl/cluster.yaml                 # EKS cluster definition (OIDC enabled)
├── iam/eso-policy.json                 # least-privilege IAM policy for ESO
├── scripts/
│   ├── 00-env.sh                       # variables (source this first)
│   ├── 01-create-cluster.sh
│   ├── 02-create-aws-secrets.sh        # creates the 2 demo secrets in AWS
│   ├── 03-create-iam-irsa.sh           # IAM policy + IRSA service account
│   ├── 04-install-eso.sh               # helm install external-secrets
│   ├── 05-apply-manifests.sh           # applies everything in k8s/
│   ├── 06-rotate-secret.sh             # change secret in AWS, watch K8s update
│   └── 99-cleanup.sh                   # delete EVERYTHING (stop the bill)
├── k8s/
│   ├── 01-namespace.yaml
│   ├── 02-clustersecretstore.yaml      # "how to log in to AWS"
│   ├── 03-externalsecret-basic.yaml    # plain-text secret
│   ├── 04-externalsecret-property.yaml # one key out of a JSON secret
│   ├── 05-externalsecret-extract.yaml  # all keys of a JSON secret
│   ├── 06-externalsecret-template.yaml # build DATABASE_URL from parts
│   ├── 07-demo-app.yaml                # pod that consumes the secrets
│   └── optional/
│       ├── secretstore-namespaced-jwt.yaml
│       └── externalsecret-find.yaml
└── local-lab/                          # Path B (free, no AWS account)
```

## Path A — step by step

Prerequisites: `aws` (configured with an admin-ish user), `eksctl`, `kubectl`, `helm`, `jq`.

```bash
cd eso-aws-secrets-demo
source scripts/00-env.sh          # sets region, cluster name, account id
bash scripts/01-create-cluster.sh # ~15-20 min
bash scripts/02-create-aws-secrets.sh
bash scripts/03-create-iam-irsa.sh
bash scripts/04-install-eso.sh
bash scripts/05-apply-manifests.sh
```

### Verify (the important part — learn to read these)

```bash
kubectl get clustersecretstore                 # STATUS should be Valid, READY True
kubectl -n demo get externalsecret             # STATUS SecretSynced, READY True
kubectl -n demo get secret                     # db-password-k8s, app-config-k8s, app-config-props-k8s, db-url-k8s
kubectl -n demo get secret db-password-k8s -o jsonpath='{.data.password}' | base64 -d; echo
kubectl -n demo logs deploy/demo-app --tail=5
kubectl -n demo describe externalsecret db-password   # read Events + Status
```

### Rotation experiment

```bash
bash scripts/06-rotate-secret.sh
```
Watch: the Kubernetes Secret changes within the refresh interval (1 minute in this demo).
The **volume-mounted** value in the pod updates by itself; the **env var** value does NOT until the
pod restarts. This is a classic real-time interview question.

### Cleanup (do not skip)

```bash
bash scripts/99-cleanup.sh
```

## Practice challenges (do these to become "hero")

1. Change `refreshInterval` to `15s` and observe. Why is a very low value a bad idea in production? (API cost, throttling.)
2. Add a third secret `demo/api-key` and write your own ExternalSecret for it.
3. Break it on purpose, then fix it using `describe externalsecret`:
   - Wrong secret name in `remoteRef.key`  → `ResourceNotFoundException`
   - Remove the IAM permission              → `AccessDeniedException`
   - Wrong namespace in the IRSA trust      → `AssumeRoleWithWebIdentity` error
4. Convert the ClusterSecretStore into a namespaced SecretStore (see `k8s/optional/`).
5. Use `dataFrom.find` (see `k8s/optional/externalsecret-find.yaml`) — note it needs `secretsmanager:ListSecrets`.
6. Install **Stakater Reloader** so pods restart automatically when a Secret changes.
7. Try EKS **Pod Identity** instead of IRSA (steps are in the notes .docx).

> ⚠️ The demo app prints secret values to its logs ONLY so you can see rotation happen.
> Never log secrets in real applications.

> ⚠️ I wrote this project carefully, but have verified only the YAML/JSON syntax and shell syntax in my
> sandbox — I could not run it against a real EKS cluster. If a command output differs (versions change),
> read the error, check the Troubleshooting chapter in the notes, and adjust.
