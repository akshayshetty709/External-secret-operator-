#!/usr/bin/env bash
# Deletes everything created by this demo. Run it when you finish practicing to stop the AWS bill.
set -uo pipefail
: "${AWS_REGION:?run: source scripts/00-env.sh first}"
cd "$(dirname "$0")/.."

echo ">> 1. Delete Kubernetes demo resources"
kubectl delete -f k8s/07-demo-app.yaml --ignore-not-found
kubectl delete -f k8s/06-externalsecret-template.yaml --ignore-not-found
kubectl delete -f k8s/05-externalsecret-extract.yaml --ignore-not-found
kubectl delete -f k8s/04-externalsecret-property.yaml --ignore-not-found
kubectl delete -f k8s/03-externalsecret-basic.yaml --ignore-not-found
kubectl delete -f k8s/02-clustersecretstore.yaml --ignore-not-found
kubectl delete -f k8s/01-namespace.yaml --ignore-not-found

echo ">> 2. Uninstall ESO"
helm uninstall external-secrets -n "$ESO_NAMESPACE" || true

echo ">> 3. Delete IRSA service account + IAM role"
eksctl delete iamserviceaccount --cluster "$CLUSTER_NAME" --region "$AWS_REGION" \
  --namespace "$ESO_NAMESPACE" --name "$ESO_SA_NAME" || true

echo ">> 4. Delete IAM policy"
aws iam delete-policy --policy-arn "$POLICY_ARN" || true

echo ">> 5. Delete AWS secrets immediately (no 7-30 day recovery window)"
aws secretsmanager delete-secret --secret-id demo/db-password --force-delete-without-recovery --region "$AWS_REGION" || true
aws secretsmanager delete-secret --secret-id demo/app-config --force-delete-without-recovery --region "$AWS_REGION" || true

echo ">> 6. Delete the EKS cluster (~10-15 min)"
eksctl delete cluster --name "$CLUSTER_NAME" --region "$AWS_REGION"

echo ">> Done. Double-check the AWS console (EKS, EC2, CloudFormation, Secrets Manager) for leftovers."
