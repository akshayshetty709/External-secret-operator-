#!/usr/bin/env bash
set -euo pipefail
: "${ESO_NAMESPACE:?run: source scripts/00-env.sh first}"

helm repo add external-secrets https://charts.external-secrets.io
helm repo update

# serviceAccount.create=false  -> we reuse the IRSA service account that eksctl created
helm upgrade --install external-secrets external-secrets/external-secrets \
  --namespace "$ESO_NAMESPACE" \
  --set installCRDs=true \
  --set serviceAccount.create=false \
  --set serviceAccount.name="$ESO_SA_NAME" \
  --wait

echo ">> Operator pods:"
kubectl -n "$ESO_NAMESPACE" get pods

echo ">> CRDs installed by ESO:"
kubectl get crd | grep external-secrets.io

echo ">> Proof that IRSA is wired: the controller pod should have these env vars injected by EKS"
POD=$(kubectl -n "$ESO_NAMESPACE" get pod -l app.kubernetes.io/name=external-secrets -o jsonpath='{.items[0].metadata.name}')
kubectl -n "$ESO_NAMESPACE" exec "$POD" -- env | grep -E 'AWS_ROLE_ARN|AWS_WEB_IDENTITY_TOKEN_FILE' || \
  echo "(exec not available in this image - instead run: kubectl -n $ESO_NAMESPACE get pod $POD -o yaml | grep -i AWS_)"
