#!/usr/bin/env bash
# Usage: source scripts/00-env.sh
export AWS_REGION=ap-south-1
export AWS_DEFAULT_REGION=$AWS_REGION
export CLUSTER_NAME=eso-demo
export ESO_NAMESPACE=external-secrets
export ESO_SA_NAME=external-secrets
export POLICY_NAME=ESODemoSecretsReadPolicy
export ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
export POLICY_ARN="arn:aws:iam::${ACCOUNT_ID}:policy/${POLICY_NAME}"

echo "Region      : $AWS_REGION"
echo "Cluster     : $CLUSTER_NAME"
echo "Account ID  : $ACCOUNT_ID"
echo "Policy ARN  : $POLICY_ARN"
