#!/usr/bin/env bash
# Creates: IAM policy (read demo/* secrets) + IAM role + K8s ServiceAccount linked together (IRSA)
set -euo pipefail
cd "$(dirname "$0")/.."
: "${ACCOUNT_ID:?run: source scripts/00-env.sh first}"

echo ">> 1. Render policy with your account id / region"
sed "s/__ACCOUNT_ID__/${ACCOUNT_ID}/g; s/__AWS_REGION__/${AWS_REGION}/g" iam/eso-policy.json > /tmp/eso-policy-rendered.json
cat /tmp/eso-policy-rendered.json

echo ">> 2. Create IAM policy (ignore 'already exists' on re-run)"
aws iam create-policy \
  --policy-name "$POLICY_NAME" \
  --policy-document file:///tmp/eso-policy-rendered.json || echo "(policy already exists - continuing)"

echo ">> 3. Create namespace for the operator"
kubectl create namespace "$ESO_NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -

echo ">> 4. Create IAM role + annotated ServiceAccount (IRSA) with eksctl"
eksctl create iamserviceaccount \
  --cluster "$CLUSTER_NAME" \
  --region "$AWS_REGION" \
  --namespace "$ESO_NAMESPACE" \
  --name "$ESO_SA_NAME" \
  --attach-policy-arn "$POLICY_ARN" \
  --approve \
  --override-existing-serviceaccounts

echo ">> 5. Look at the magic: the annotation that links the ServiceAccount to the IAM role"
kubectl -n "$ESO_NAMESPACE" get sa "$ESO_SA_NAME" -o yaml | grep -A2 annotations
