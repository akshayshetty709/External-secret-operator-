#!/usr/bin/env bash
# Creates two demo secrets in AWS Secrets Manager.
set -euo pipefail
: "${AWS_REGION:?run: source scripts/00-env.sh first}"

echo ">> Secret 1: plain-text secret"
aws secretsmanager create-secret \
  --name demo/db-password \
  --description "Demo plain text secret for ESO practice" \
  --secret-string 'MyS3cretP@ss-v1' \
  --region "$AWS_REGION"

echo ">> Secret 2: JSON secret (multiple keys in one secret - very common in real projects)"
aws secretsmanager create-secret \
  --name demo/app-config \
  --description "Demo JSON secret for ESO practice" \
  --secret-string '{"username":"admin","password":"S3cr3t!v1","host":"mydb.example.internal","port":"5432"}' \
  --region "$AWS_REGION"

echo ">> Check:"
aws secretsmanager list-secrets --region "$AWS_REGION" \
  --query "SecretList[?starts_with(Name, 'demo/')].Name" --output table
