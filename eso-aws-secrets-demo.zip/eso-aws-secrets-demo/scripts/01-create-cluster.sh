#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

echo ">> Creating EKS cluster (takes ~15-20 minutes, costs money while running)"
eksctl create cluster -f eksctl/cluster.yaml

echo ">> Verifying"
kubectl get nodes
echo ">> OIDC issuer (this is what AWS IAM trusts for IRSA):"
aws eks describe-cluster --name eso-demo --region ap-south-1 \
  --query "cluster.identity.oidc.issuer" --output text
