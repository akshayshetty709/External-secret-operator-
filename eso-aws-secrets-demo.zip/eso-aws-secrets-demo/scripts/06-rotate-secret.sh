#!/usr/bin/env bash
# Simulates secret rotation: change values in AWS, then watch Kubernetes pick them up.
set -euo pipefail
: "${AWS_REGION:?run: source scripts/00-env.sh first}"

show() {
  echo "  K8s Secret db-password-k8s  : $(kubectl -n demo get secret db-password-k8s -o jsonpath='{.data.password}' | base64 -d)"
  echo "  K8s Secret app-config-k8s   : $(kubectl -n demo get secret app-config-k8s -o jsonpath='{.data.password}' | base64 -d)"
}

echo "=== BEFORE rotation ==="; show

echo ">> Rotating secrets in AWS (put-secret-value creates a NEW VERSION)"
aws secretsmanager put-secret-value --secret-id demo/db-password \
  --secret-string 'MyS3cretP@ss-v2' --region "$AWS_REGION" >/dev/null
aws secretsmanager put-secret-value --secret-id demo/app-config \
  --secret-string '{"username":"admin","password":"S3cr3t!v2","host":"mydb.example.internal","port":"5432"}' \
  --region "$AWS_REGION" >/dev/null

echo ">> Waiting 75s (refreshInterval is 1m in this demo)..."
sleep 75

echo "=== AFTER rotation (Kubernetes Secrets) ==="; show

echo
echo "=== What the POD sees (read the last lines) ==="
echo "  env var  -> still OLD until the pod restarts"
echo "  file     -> NEW (kubelet refreshes mounted secret volumes, can take up to ~1-2 min)"
kubectl -n demo logs deploy/demo-app --tail=3

echo
echo "To make the env var update, restart the pod:  kubectl -n demo rollout restart deploy/demo-app"
