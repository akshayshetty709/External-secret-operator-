#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../k8s"

for f in 01-namespace.yaml 02-clustersecretstore.yaml; do
  echo ">> apply $f"; kubectl apply -f "$f"
done

echo ">> waiting for the store to become Valid..."
sleep 5
kubectl get clustersecretstore

for f in 03-externalsecret-basic.yaml 04-externalsecret-property.yaml 05-externalsecret-extract.yaml 06-externalsecret-template.yaml 07-demo-app.yaml; do
  echo ">> apply $f"; kubectl apply -f "$f"
done

echo ">> waiting ~20s for first sync"
sleep 20
kubectl -n demo get externalsecret
kubectl -n demo get secret
